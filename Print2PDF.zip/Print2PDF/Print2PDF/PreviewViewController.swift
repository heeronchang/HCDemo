//
//  PreviewViewController.swift
//  Print2PDF
//
//  Created by Gabriel Theodoropoulos on 14/06/16.
//  Copyright © 2016 Appcoda. All rights reserved.
//

import UIKit
import MessageUI

class PreviewViewController: UIViewController {

    @IBOutlet weak var webPreview: UIWebView!
    
    var invoiceInfo: [String: AnyObject]!
    
    var invoiceComposer: InvoiceComposer!
    
    var HTMLContent: String!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        createInvoiceAsHTML()
    }
    
    func createInvoiceAsHTML() {
        invoiceComposer = InvoiceComposer()
        
        if let invoiceHTML = invoiceComposer.renderInvoice(invoiceNumber: invoiceInfo["invoiceNumber"] as! String,
                                                           invoiceDate: invoiceInfo["invoiceDate"] as! String,
                                                           recipientInfo: invoiceInfo["recipientInfo"] as! String,
                                                           items: invoiceInfo["items"] as! [[String: String]],
                                                           totalAmount: invoiceInfo["totalAmount"] as! String) {
            webPreview.loadHTMLString(invoiceHTML, baseURL: NSURL(fileURLWithPath: invoiceComposer.pathToInvoiceHTMLTemplate!) as URL)
            
            HTMLContent = invoiceHTML
        }
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

    
    // MARK: IBAction Methods
    
    @IBAction func exportToPDF(_ sender: AnyObject) {
        invoiceComposer.exportHTMLContentToPDF(HTMLContent: HTMLContent)
        
        self.showOptionsAlert()
    }
    
    func showOptionsAlert() -> Void {
        let alertController = UIAlertController(title: "Yeah!", message: "Your invoince has successfully printed a PDF file.\n\n What do you want to do now?", preferredStyle: .alert)
        let actionPreview = UIAlertAction(title: "Preview it", style: UIAlertActionStyle.default) { (action) in
            let request = URLRequest(url: URL(fileURLWithPath: self.invoiceComposer.pdfFilename))
            self.webPreview.loadRequest(request)
        }
        
        let actionMore = UIAlertAction(title: "More", style: UIAlertActionStyle.default) { (action) in
            self.activityControl()
//            self.print()
        }
        
        let actionNothing = UIAlertAction(title: "Nothing", style: UIAlertActionStyle.cancel) { (action) in
            
        }
        
        alertController.addAction(actionPreview)
        alertController.addAction(actionMore)
        alertController.addAction(actionNothing)
        
        present(alertController, animated: true, completion: nil)
    }
    
    func activityControl() -> Void {
        let data = NSData(contentsOfFile: self.invoiceComposer.pdfFilename)
        if let shareData = data {
            let activityItems = [shareData]
            let activityController = UIActivityViewController(activityItems: activityItems, applicationActivities: nil)
            present(activityController, animated: true, completion: nil)
        }
        
    }
    
    func print() -> Void {
        // UIPrintInteractionController
        let printUIC = UIPrintInteractionController.shared
        
        let data = NSData(contentsOfFile: self.invoiceComposer.pdfFilename)
        printUIC.printingItem = data;
        
        printUIC.present(animated: true, completionHandler: nil)
    }
    
}
